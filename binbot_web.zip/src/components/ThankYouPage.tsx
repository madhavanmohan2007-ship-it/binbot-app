import React from 'react'
import { Button } from './ui/Button'

export function ThankYouPage({ onBackToHome, wasteType, pointsEarned }: { onBackToHome: () => void, wasteType: string, pointsEarned: number }) {
  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="max-w-md text-center p-6 bg-white rounded-lg shadow">
        <h2 className="text-2xl font-bold mb-2">Thank you!</h2>
        <p className="mb-4">You disposed: <strong>{wasteType}</strong></p>
        <p className="mb-6">Points earned: <strong>{pointsEarned}</strong></p>
        <Button onClick={onBackToHome}>Back to Home</Button>
      </div>
    </div>
  )
}
