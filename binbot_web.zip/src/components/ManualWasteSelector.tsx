import React from 'react'
import { Button } from './ui/Button'

export function ManualWasteSelector({ onSelectionComplete }: { onSelectionComplete: (t: 'metal'|'non-metal') => void }) {
  return (
    <div className="max-w-xl mx-auto">
      <div className="grid md:grid-cols-2 gap-4">
        <div className="p-4 bg-blue-50 rounded-lg border border-blue-200 text-center">
          <h3 className="text-lg font-medium text-blue-800 mb-2">Metal Waste</h3>
          <p className="text-sm text-blue-700 mb-4">Cans, wires, metal parts</p>
          <Button onClick={() => onSelectionComplete('metal')}>Select Metal</Button>
        </div>
        <div className="p-4 bg-green-50 rounded-lg border border-green-200 text-center">
          <h3 className="text-lg font-medium text-green-800 mb-2">Non-Metal Waste</h3>
          <p className="text-sm text-green-700 mb-4">Plastic, glass, paper</p>
          <Button onClick={() => onSelectionComplete('non-metal')}>Select Non-Metal</Button>
        </div>
      </div>
    </div>
  )
}
