import React from 'react'
export const Badge = ({ children, className='' }: any) => <span className={`inline-block px-2 py-1 rounded ${className}`}>{children}</span>
