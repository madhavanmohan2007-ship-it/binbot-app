import React from 'react'
export const Separator = () => <hr className='my-4' />
