import React from 'react'
export const Card = ({ children, className='' }: any) => <div className={`bg-white rounded-lg shadow ${className}`}>{children}</div>
export const CardHeader = ({ children }: any) => <div className='p-4 border-b'>{children}</div>
export const CardTitle = ({ children, className='' }: any) => <div className={`text-lg font-semibold ${className}`}>{children}</div>
export const CardContent = ({ children, className='' }: any) => <div className={`p-4 ${className}`}>{children}</div>
