import React from 'react'

export const Button = ({ children, onClick, className='', variant='solid', size='md' }: any) => {
  const base = 'inline-flex items-center px-4 py-2 rounded-md shadow-sm'
  const variantClass = variant === 'outline' ? 'border' : ''
  return <button onClick={onClick} className={`${base} ${variantClass} ${className}`}>{children}</button>
}
