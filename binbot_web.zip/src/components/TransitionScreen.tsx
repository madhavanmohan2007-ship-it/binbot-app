import React, { useEffect } from 'react'

export function TransitionScreen({ wasteType, onTransitionComplete }: { wasteType: string, onTransitionComplete: () => void }) {
  useEffect(() => {
    const id = setTimeout(() => onTransitionComplete(), 1400)
    return () => clearTimeout(id)
  }, [onTransitionComplete])

  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="text-center">
        <div className="text-2xl">Processing {wasteType}...</div>
        <div className="mt-4 animate-pulse">🔄</div>
      </div>
    </div>
  )
}
