import { useState } from "react";
import { ManualWasteSelector } from "./components/ManualWasteSelector";
import { TransitionScreen } from "./components/TransitionScreen";
import { ThankYouPage } from "./components/ThankYouPage";
import { Button } from "./components/ui/Button";
import { Card, CardContent, CardHeader, CardTitle } from "./components/ui/Card";
import { Badge } from "./components/ui/Badge";
import { Separator } from "./components/ui/Separator";
import { 
  Bot, 
  Zap, 
  Package, 
  Recycle, 
  Hand,
  Trash2,
  Star,
  ArrowRight,
  RefreshCw
} from "lucide-react";

type AppState = "welcome" | "selection" | "transition" | "complete";

export default function App() {
  const [currentState, setCurrentState] = useState<AppState>("welcome");
  const [selectedWaste, setSelectedWaste] = useState<{
    type: "metal" | "non-metal";
    material: string;
  } | null>(null);

  const handleSelectionComplete = (wasteType: "metal" | "non-metal") => {
    const materials = {
      metal: ["Aluminum Can", "Steel Container", "Copper Wire", "Brass Fitting", "Iron Component"],
      "non-metal": ["Plastic Bottle", "Glass Jar", "Paper Waste", "Cardboard Box", "Food Container"]
    };

    const material = materials[wasteType][Math.floor(Math.random() * materials[wasteType].length)];

    setSelectedWaste({
      type: wasteType,
      material
    });

    setCurrentState("transition");
  };

  const handleTransitionComplete = () => {
    setCurrentState("complete");
  };

  const handleRestart = () => {
    setCurrentState("welcome");
    setSelectedWaste(null);
  };

  const stats = [
    { label: "Items Processed Today", value: "127", icon: <Trash2 className="h-4 w-4" /> },
    { label: "CO2 Saved", value: "45kg", icon: <Recycle className="h-4 w-4" /> },
    { label: "User Selections", value: "98.5%", icon: <Hand className="h-4 w-4" /> },
    { label: "Active Users", value: "89", icon: <Star className="h-4 w-4" /> }
  ];

  if (currentState === "transition") {
    return (
      <TransitionScreen 
        wasteType={selectedWaste?.type || "metal"}
        onTransitionComplete={handleTransitionComplete}
      />
    );
  }

  if (currentState === "complete") {
    return (
      <ThankYouPage 
        onBackToHome={handleRestart}
        wasteType={selectedWaste?.material || "Unknown Waste"}
        pointsEarned={selectedWaste?.type === "metal" ? 200 : 150}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50 p-4">
      <div className="max-w-4xl mx-auto space-y-6">

        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="relative">
              <Bot className="h-12 w-12 text-blue-600" />
              <div className="absolute -top-1 -right-1 w-4 h-4 bg-green-500 rounded-full animate-pulse"></div>
            </div>
            <div className="text-left">
              <h1 className="text-blue-600">BinBot</h1>
              <p className="text-sm text-muted-foreground">Smart Waste Collection System</p>
            </div>
          </div>

          {currentState === "welcome" && (
            <div className="space-y-2">
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Welcome to BinBot! Simply select your waste type and earn instant rewards for responsible disposal.
              </p>
              <Badge variant="secondary" className="bg-green-100 text-green-800">
                Manual Selection Mode
              </Badge>
            </div>
          )}
        </div>

        {/* Stats Bar */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {stats.map((stat, index) => (
            <Card key={index} className="text-center">
              <CardContent className="p-3">
                <div className="flex items-center justify-center gap-2 mb-1">
                  {stat.icon}
                  <span className="text-lg font-medium">{stat.value}</span>
                </div>
                <p className="text-xs text-muted-foreground">{stat.label}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <Separator />

        {/* Main Content */}
        <div className="space-y-6">

          {currentState === "welcome" && (
            <div className="space-y-6">

              {/* Welcome Screen */}
              <Card className="text-center">
                <CardHeader>
                  <CardTitle className="flex items-center justify-center gap-2">
                    <Hand className="h-5 w-5 text-blue-600" />
                    Manual Waste Selection
                  </CardTitle>
                  <p className="text-muted-foreground">
                    Choose your waste category and earn instant rewards
                  </p>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid md:grid-cols-2 gap-4">

                    {/* Metal Waste Info */}
                    <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                      <div className="flex items-center gap-2 mb-2">
                        <Zap className="h-5 w-5 text-blue-600" />
                        <h4 className="text-blue-800">Metal Waste</h4>
                      </div>
                      <p className="text-sm text-blue-700 mb-2">
                        Cans, wires, metal parts, electronics
                      </p>
                      <Badge variant="outline" className="border-blue-300 text-blue-700">
                        200 Points Reward
                      </Badge>
                    </div>

                    {/* Non-Metal Waste Info */}
                    <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                      <div className="flex items-center gap-2 mb-2">
                        <Package className="h-5 w-5 text-green-600" />
                        <h4 className="text-green-800">Non-Metal Waste</h4>
                      </div>
                      <p className="text-sm text-green-700 mb-2">
                        Plastic, glass, paper, organic waste
                      </p>
                      <Badge variant="outline" className="border-green-300 text-green-700">
                        150 Points Reward
                      </Badge>
                    </div>
                  </div>

                  <Button 
                    onClick={() => setCurrentState("selection")}
                    size="lg"
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    <ArrowRight className="h-4 w-4 mr-2" />
                    Start Manual Selection
                  </Button>
                </CardContent>
              </Card>

              {/* Instructions */}
              <Card>
                <CardHeader>
                  <CardTitle>How Manual Selection Works</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-3 gap-4">
                    <div className="text-center space-y-2">
                      <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto">
                        <Hand className="h-6 w-6 text-blue-600" />
                      </div>
                      <h4>1. Select Category</h4>
                      <p className="text-sm text-muted-foreground">
                        Choose between metal or non-metal waste
                      </p>
                    </div>
                    <div className="text-center space-y-2">
                      <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                        <Trash2 className="h-6 w-6 text-green-600" />
                      </div>
                      <h4>2. Confirm Disposal</h4>
                      <p className="text-sm text-muted-foreground">
                        System processes your selection automatically
                      </p>
                    </div>
                    <div className="text-center space-y-2">
                      <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center mx-auto">
                        <Star className="h-6 w-6 text-yellow-600" />
                      </div>
                      <h4>3. Instant Rewards</h4>
                      <p className="text-sm text-muted-foreground">
                        Earn points and coupons immediately
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {currentState === "selection" && (
            <div className="space-y-6">
              <ManualWasteSelector onSelectionComplete={handleSelectionComplete} />

              <div className="text-center">
                <Button onClick={handleRestart} variant="outline">
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Back to Home
                </Button>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <Separator />
        <div className="text-center text-sm text-muted-foreground">
          <p>
            BinBot v2.0 - Powered by AI • Making waste disposal smart and rewarding
          </p>
        </div>
      </div>
    </div>
  );
}
