# BinBot Web (Ready-to-deploy)

This is a minimal Vite + React + TypeScript project created from your supplied App component.
It includes simplified UI primitives (Button, Card, Badge) to avoid extra dependencies.

## How to run locally

1. Install dependencies:
   ```bash
   npm install
   ```
2. Run dev server:
   ```bash
   npm run dev
   ```
3. Open the URL printed by Vite (usually http://localhost:5173)

## Deploy to Vercel (quickest way to get a URL)

1. Create a GitHub repository and push this project.
2. Sign in to Vercel, choose "Import Project" and connect your GitHub repo.
3. Vercel automatically detects the project. Click Deploy — you get a public URL.

## Deploy to GitHub Pages (alternative)

1. Build the project: `npm run build`
2. Serve the `dist/` directory using GitHub Pages or a static host.
3. Use a GitHub Pages action or push the `dist/` to `gh-pages` branch.

Enjoy — you can now host this and get a public URL. If you want, I can also prepare a GitHub repo structure or generate the GitHub Action to auto-deploy to GitHub Pages or Vercel.
